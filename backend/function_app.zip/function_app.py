import azure.functions as func
import azure.durable_functions as df
import json
import logging
import os
from datetime import datetime, timezone
from azure.cosmos import CosmosClient, PartitionKey, exceptions
from azure.core.exceptions import AzureError
import uuid

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Initialize the Azure Function App
app = func.FunctionApp()

class CosmosDBManager:
    """
    Manages CosmosDB operations for visitor counter
    """
    
    def __init__(self):
        """Initialize CosmosDB client and configure database/container"""
        try:
            # Get connection details from environment variables
            self.cosmos_endpoint = os.environ.get('COSMOS_DB_ENDPOINT')
            self.cosmos_key = os.environ.get('COSMOS_DB_KEY')
            self.database_name = os.environ.get('COSMOS_DB_DATABASE', 'CloudResumeDB')
            self.container_name = os.environ.get('COSMOS_DB_CONTAINER', 'VisitorCounter')
            
            if not self.cosmos_endpoint or not self.cosmos_key:
                raise ValueError("CosmosDB connection details not found in environment variables")
            
            # Initialize Cosmos client
            self.client = CosmosClient(self.cosmos_endpoint, self.cosmos_key)
            
            # Get database and container references
            self.database = self.client.get_database_client(self.database_name)
            self.container = self.database.get_container_client(self.container_name)
            
            logger.info("CosmosDB client initialized successfully")
            
        except Exception as e:
            logger.error(f"Failed to initialize CosmosDB client: {str(e)}")
            raise

    def get_visitor_count(self):
        """
        Retrieve current visitor count from CosmosDB
        """
        try:
            # Query for the visitor counter item
            query = "SELECT * FROM c WHERE c.id = 'visitor-counter'"
            items = list(self.container.query_items(
                query=query,
                enable_cross_partition_query=True
            ))
            
            if items:
                count = items[0].get('count', 0)
                logger.info(f"Retrieved visitor count: {count}")
                return count
            else:
                # Initialize counter if it doesn't exist
                logger.info("Visitor counter not found, initializing...")
                return self.initialize_counter()
                
        except exceptions.CosmosResourceNotFoundError:
            logger.info("Container not found, initializing counter...")
            return self.initialize_counter()
        except Exception as e:
            logger.error(f"Error retrieving visitor count: {str(e)}")
            raise

    def increment_visitor_count(self):
        """
        Increment and return the visitor count
        """
        try:
            # Try to get existing counter
            try:
                item = self.container.read_item(
                    item='visitor-counter',
                    partition_key='visitor-counter'
                )
                current_count = item.get('count', 0)
            except exceptions.CosmosResourceNotFoundError:
                # Counter doesn't exist, start with 0
                current_count = 0
            
            # Increment the count
            new_count = current_count + 1
            
            # Update or create the counter item
            counter_item = {
                'id': 'visitor-counter',
                'count': new_count,
                'lastUpdated': datetime.now(timezone.utc).isoformat(),
                'version': str(uuid.uuid4())
            }
            
            # Upsert the item (create or update)
            self.container.upsert_item(counter_item)
            
            logger.info(f"Visitor count incremented to: {new_count}")
            return new_count
            
        except Exception as e:
            logger.error(f"Error incrementing visitor count: {str(e)}")
            raise

    def initialize_counter(self):
        """
        Initialize the visitor counter
        """
        try:
            counter_item = {
                'id': 'visitor-counter',
                'count': 1,
                'created': datetime.now(timezone.utc).isoformat(),
                'lastUpdated': datetime.now(timezone.utc).isoformat(),
                'version': str(uuid.uuid4())
            }
            
            self.container.create_item(counter_item)
            logger.info("Visitor counter initialized with count: 1")
            return 1
            
        except Exception as e:
            logger.error(f"Error initializing visitor counter: {str(e)}")
            # Return 1 as fallback
            return 1

    def get_visitor_stats(self):
        """
        Get detailed visitor statistics
        """
        try:
            # Get the main counter
            count = self.get_visitor_count()
            
            # You could extend this to get additional stats like:
            # - Daily/weekly/monthly counts
            # - Unique visitors
            # - Geographic data (if collected)
            
            stats = {
                'totalVisitors': count,
                'lastUpdated': datetime.now(timezone.utc).isoformat(),
                'status': 'active'
            }
            
            return stats
            
        except Exception as e:
            logger.error(f"Error getting visitor stats: {str(e)}")
            return {
                'totalVisitors': 0,
                'lastUpdated': datetime.now(timezone.utc).isoformat(),
                'status': 'error'
            }

# Initialize CosmosDB manager
cosmos_manager = CosmosDBManager()

@app.route(route="visitor-counter", methods=["GET", "POST", "OPTIONS"], auth_level=func.AuthLevel.ANONYMOUS)
def visitor_counter(req: func.HttpRequest) -> func.HttpResponse:
    """
    Azure Function HTTP trigger for visitor counter
    
    GET: Returns current visitor count
    POST: Increments and returns visitor count
    OPTIONS: CORS preflight
    """
    
    # Handle CORS preflight requests
    if req.method == "OPTIONS":
        return func.HttpResponse(
            status_code=200,
            headers={
                "Access-Control-Allow-Origin": "*",
                "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
                "Access-Control-Allow-Headers": "Content-Type, Authorization, x-ms-client-request-id",
                "Access-Control-Max-Age": "86400"
            }
        )
    
    try:
        logger.info(f"Visitor counter function triggered via {req.method}")
        
        # Set CORS headers for all responses
        headers = {
            "Access-Control-Allow-Origin": "*",
            "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
            "Access-Control-Allow-Headers": "Content-Type, Authorization",
            "Content-Type": "application/json"
        }
        
        if req.method == "GET":
            # Get current count without incrementing
            count = cosmos_manager.get_visitor_count()
            
            response_data = {
                "count": count,
                "timestamp": datetime.now(timezone.utc).isoformat(),
                "status": "success",
                "method": "GET"
            }
            
        elif req.method == "POST":
            # Increment count and return new value
            try:
                # Parse request body (optional, for future enhancements)
                req_body = req.get_json()
                action = req_body.get('action', 'increment') if req_body else 'increment'
                
                if action == 'increment':
                    count = cosmos_manager.increment_visitor_count()
                else:
                    count = cosmos_manager.get_visitor_count()
                
                response_data = {
                    "count": count,
                    "timestamp": datetime.now(timezone.utc).isoformat(),
                    "status": "success",
                    "method": "POST",
                    "action": action
                }
                
            except ValueError as ve:
                logger.warning(f"Invalid request body: {str(ve)}")
                # Still increment even if body is invalid
                count = cosmos_manager.increment_visitor_count()
                response_data = {
                    "count": count,
                    "timestamp": datetime.now(timezone.utc).isoformat(),
                    "status": "success",
                    "method": "POST",
                    "action": "increment",
                    "warning": "Invalid request body, defaulted to increment"
                }
        
        else:
            # Method not allowed
            return func.HttpResponse(
                json.dumps({
                    "error": "Method not allowed",
                    "allowed_methods": ["GET", "POST", "OPTIONS"]
                }),
                status_code=405,
                headers=headers
            )
        
        logger.info(f"Returning visitor count: {response_data['count']}")
        
        return func.HttpResponse(
            json.dumps(response_data),
            status_code=200,
            headers=headers
        )
        
    except Exception as e:
        logger.error(f"Error in visitor counter function: {str(e)}")
        
        error_response = {
            "error": "Internal server error",
            "message": "Failed to process visitor counter request",
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "status": "error"
        }
        
        return func.HttpResponse(
            json.dumps(error_response),
            status_code=500,
            headers={
                "Access-Control-Allow-Origin": "*",
                "Content-Type": "application/json"
            }
        )

@app.route(route="visitor-stats", methods=["GET"], auth_level=func.AuthLevel.ANONYMOUS)
def visitor_stats(req: func.HttpRequest) -> func.HttpResponse:
    """
    Azure Function to get detailed visitor statistics
    """
    
    try:
        logger.info("Visitor stats function triggered")
        
        headers = {
            "Access-Control-Allow-Origin": "*",
            "Content-Type": "application/json"
        }
        
        # Get detailed statistics
        stats = cosmos_manager.get_visitor_stats()
        
        return func.HttpResponse(
            json.dumps(stats),
            status_code=200,
            headers=headers
        )
        
    except Exception as e:
        logger.error(f"Error in visitor stats function: {str(e)}")
        
        error_response = {
            "error": "Failed to retrieve visitor statistics",
            "timestamp": datetime.now(timezone.utc).isoformat()
        }
        
        return func.HttpResponse(
            json.dumps(error_response),
            status_code=500,
            headers={
                "Access-Control-Allow-Origin": "*",
                "Content-Type": "application/json"
            }
        )

@app.route(route="health", methods=["GET"], auth_level=func.AuthLevel.ANONYMOUS)
def health_check(req: func.HttpRequest) -> func.HttpResponse:
    """
    Health check endpoint for monitoring
    """
    
    try:
        # Test CosmosDB connection
        test_count = cosmos_manager.get_visitor_count()
        
        health_data = {
            "status": "healthy",
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "services": {
                "cosmosdb": "connected",
                "function_app": "running"
            },
            "version": "1.0.0"
        }
        
        return func.HttpResponse(
            json.dumps(health_data),
            status_code=200,
            headers={
                "Content-Type": "application/json",
                "Cache-Control": "no-cache"
            }
        )
        
    except Exception as e:
        logger.error(f"Health check failed: {str(e)}")
        
        health_data = {
            "status": "unhealthy",
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "services": {
                "cosmosdb": "error",
                "function_app": "running"
            },
            "error": str(e)
        }
        
        return func.HttpResponse(
            json.dumps(health_data),
            status_code=503,
            headers={
                "Content-Type": "application/json",
                "Cache-Control": "no-cache"
            }
        )