# Azure Functions Backend for Cloud Resume Challenge
# This package contains the visitor counter API and database interactions